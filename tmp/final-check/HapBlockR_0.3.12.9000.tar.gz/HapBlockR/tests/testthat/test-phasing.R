## tests/testthat/test-phasing.R
## -----------------------------------------------------------------------------
## Tests for the Beagle phasing layer:
##   .write_cleaned_vcf()       - internal VCF writer (pipeline.R)
##   phase_with_beagle()        - Java/Beagle wrapper (haplotypes.R)
##   read_phased_vcf()          - phased-VCF reader  (haplotypes.R)
##   run_ldx_pipeline(phase=TRUE) - end-to-end integration
##
## Test organisation
## -----------------
## Section 1 - .write_cleaned_vcf(): pure-R, no JAR needed.
##   Tests VCF format compliance, sorting, encoding, and round-trip fidelity.
##
## Section 2 - phase_with_beagle() argument validation: no JAR needed.
##   Tests that invalid arguments are caught before any Java is called.
##
## Section 3 - phase_with_beagle() + read_phased_vcf() integration: JAR required.
##   All tests in this section are wrapped in:
##     skip_if(!.beagle_works(), "Beagle not functional ...")
##   .beagle_works() checks java on PATH + beagle.jar in inst/extdata +
##   runs a smoke test to verify Beagle executes successfully.
##   The JAR is expected at:
##     system.file("extdata", "beagle.jar", package = "HapBlockR")
##   Copy beagle.jar there before running these tests.
##
## Section 4 - run_ldx_pipeline(phase=TRUE): JAR required (same skip guard).
##
## Section 5 - read_phased_vcf(): tests on hand-crafted phased VCF, no JAR.
## -----------------------------------------------------------------------------

library(testthat)
library(HapBlockR)

# Integration tests request the structured provenance/QC result explicitly.
.phase_with_beagle <- HapBlockR::phase_with_beagle
phase_with_beagle <- function(...) {
  .phase_with_beagle(..., return_details = TRUE)
}

data(ldx_geno,     package = "HapBlockR")
data(ldx_snp_info, package = "HapBlockR")
data(ldx_blocks,   package = "HapBlockR")

# -- Helper: locate beagle.jar -------------------------------------------------
.beagle_jar_path <- function() {
  configured <- getOption(
    "HapBlockR.beagle_jar",
    Sys.getenv("HAPBLOCKR_BEAGLE_JAR", unset = "")
  )
  if (nzchar(configured)) configured else ""
}
.beagle_available <- function() {
  j <- .beagle_jar_path()
  nzchar(j) && file.exists(j)
}

# .beagle_works() - cached smoke-test: can Beagle actually execute?
# Returns TRUE only when java is on PATH AND beagle.jar is found AND
# a minimal phasing run exits with status 0.
# Result is cached per session (one Beagle call across all 10 tests).
# IMPORTANT: builds its own minimal VCF inline - does NOT depend on
# .G30/.si30/.wcv which are defined later in this file.
.beagle_works_cache <- NULL
.beagle_works <- function() {
  if (!is.null(.beagle_works_cache)) return(.beagle_works_cache)
  if (Sys.which("java") == "" || !.beagle_available()) {
    .beagle_works_cache <<- FALSE
    return(FALSE)
  }
  tmp <- tempfile(); dir.create(tmp)
  on.exit(unlink(tmp, recursive = TRUE), add = TRUE)
  vcf_in <- file.path(tmp, "smoke.vcf.gz")
  ok <- FALSE
  tryCatch({
    # Write a 5-SNP, 10-individual minimal unphased VCF inline.
    # Using HapBlockR:::.write_cleaned_vcf is avoided here because it
    # may not be loaded yet; instead write a hand-crafted VCF directly.
    n_ind  <- 10L
    n_snp  <- 5L
    set.seed(42L)
    G_sm   <- matrix(sample(0:2, n_ind * n_snp, replace = TRUE),
                     nrow = n_ind, ncol = n_snp)
    rownames(G_sm) <- paste0("ind", seq_len(n_ind))
    gt_map <- c("0" = "0/0", "1" = "0/1", "2" = "1/1")
    gt_mat <- matrix(gt_map[as.character(G_sm)], nrow = n_ind)
    vcf_lines <- c(
      "##fileformat=VCFv4.2",
      "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
      paste(c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT",
              rownames(G_sm)), collapse = "\t")
    )
    for (s in seq_len(n_snp)) {
      vcf_lines <- c(vcf_lines, paste(
        c("1", s * 1000L, paste0("rs", s), "A", "T", ".", "PASS", ".", "GT",
          gt_mat[, s]), collapse = "\t"))
    }
    con <- gzcon(file(vcf_in, "wb"))
    writeLines(vcf_lines, con)
    close(con)
    result <- suppressWarnings(
      phase_with_beagle(
        input_vcf  = vcf_in,
        out_prefix = file.path(tmp, "smoke"),
        beagle_jar = .beagle_jar_path(),
        nthreads   = 1L,
        verbose    = FALSE
      )
    )
    ok <- is.list(result) && file.exists(result$output_vcf)
  }, error = function(e) {
    ok <<- FALSE
  })
  .beagle_works_cache <<- ok
  ok
}

test_that("configured Beagle integration lane cannot silently skip", {
  if (identical(tolower(Sys.getenv("HAPBLOCKR_BEAGLE_REQUIRED")), "true"))
    expect_true(.beagle_works())
})

# -- Shared small dataset (30 SNPs, chr 1) -------------------------------------
# Use a 30-SNP subset of ldx_geno chr1 for fast tests.
.idx30 <- which(ldx_snp_info$CHR == "1")[1:30]
.G30   <- ldx_geno[, .idx30]
.si30  <- ldx_snp_info[.idx30, ]

# ==============================================================================
# Section 1: .write_cleaned_vcf() - no JAR required
# ==============================================================================

# Access the internal function via HapBlockR:::.write_cleaned_vcf
.wcv <- HapBlockR:::.write_cleaned_vcf

test_that(".write_cleaned_vcf: produces a gzip-compressed file", {
  tmp <- tempfile(fileext = ".vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), tmp, verbose = FALSE)
  expect_true(file.exists(tmp))
  # gzip magic bytes: 1f 8b
  raw <- readBin(tmp, raw(), n = 2L)
  expect_equal(as.integer(raw), c(0x1f, 0x8b))
  unlink(tmp)
})

test_that(".write_cleaned_vcf: VCF has correct header lines", {
  tmp <- tempfile(fileext = ".vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), tmp, verbose = FALSE)
  con   <- gzcon(file(tmp, "rb"))
  lines <- readLines(con, n = 50L)
  close(con)
  expect_true(any(startsWith(lines, "##fileformat=VCFv")))
  chrom_line <- lines[startsWith(lines, "#CHROM")]
  expect_equal(length(chrom_line), 1L)
  fields <- strsplit(chrom_line, "\t")[[1]]
  expect_equal(fields[1:9],
               c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT"))
  # Sample IDs in the header must match rownames of geno_mat
  expect_equal(fields[10:length(fields)], rownames(.G30))
  unlink(tmp)
})

test_that(".write_cleaned_vcf: data lines sorted by CHR then POS", {
  # Mix chromosomes to test sort: use 10 chr1 + 10 chr2 SNPs
  idx_mix <- c(which(ldx_snp_info$CHR == "1")[1:10],
               which(ldx_snp_info$CHR == "2")[1:10])
  G_mix  <- ldx_geno[, idx_mix]
  si_mix <- ldx_snp_info[idx_mix, ]
  tmp <- tempfile(fileext = ".vcf.gz")
  .wcv(G_mix, si_mix, rownames(G_mix), tmp, verbose = FALSE)
  con <- gzcon(file(tmp, "rb"))
  lines <- readLines(con)
  close(con)
  data_lines <- lines[!startsWith(lines, "#")]
  chrs <- sapply(strsplit(data_lines, "\t"), `[[`, 1)
  pos  <- as.integer(sapply(strsplit(data_lines, "\t"), `[[`, 2))
  # Within each CHR block, POS must be strictly increasing
  for (chr in unique(chrs)) {
    pos_chr <- pos[chrs == chr]
    expect_true(all(diff(pos_chr) > 0),
                label = paste("CHR", chr, "positions not sorted"))
  }
  # CHR "1" must come before CHR "2"
  expect_true(which(chrs == "1")[1] < which(chrs == "2")[1])
  unlink(tmp)
})

test_that(".write_cleaned_vcf: GT encoding correct for all dosage values", {
  # Build a 4-individual mini matrix with known dosages
  G4 <- matrix(as.integer(c(0, 1, 2, NA)), nrow = 4, ncol = 1)
  rownames(G4) <- c("ind_ref", "ind_het", "ind_alt", "ind_na")
  colnames(G4) <- "rs_test"
  si4 <- data.frame(SNP = "rs_test", CHR = "1", POS = 1000L,
                    REF = "A", ALT = "T", stringsAsFactors = FALSE)
  tmp <- tempfile(fileext = ".vcf.gz")
  .wcv(G4, si4, rownames(G4), tmp, verbose = FALSE)
  con <- gzcon(file(tmp, "rb"))
  lines <- readLines(con)
  close(con)
  data_line <- lines[!startsWith(lines, "#")][1]
  fields <- strsplit(data_line, "\t")[[1]]
  expect_equal(fields[10], "0/0")   # dosage 0 -> REF/REF
  expect_equal(fields[11], "0/1")   # dosage 1 -> REF/ALT
  expect_equal(fields[12], "1/1")   # dosage 2 -> ALT/ALT
  expect_equal(fields[13], "./.")   # NA       -> missing
  unlink(tmp)
})

test_that(".write_cleaned_vcf: REF/ALT fallback to A/T when columns absent", {
  si_no_ra <- .si30[, c("SNP","CHR","POS")]   # no REF/ALT columns
  tmp <- tempfile(fileext = ".vcf.gz")
  expect_no_error(.wcv(.G30, si_no_ra, rownames(.G30), tmp, verbose = FALSE))
  con <- gzcon(file(tmp, "rb"))
  lines <- readLines(con)
  close(con)
  data_line <- lines[!startsWith(lines, "#")][1]
  fields <- strsplit(data_line, "\t")[[1]]
  expect_equal(fields[4], "A")   # REF fallback
  expect_equal(fields[5], "T")   # ALT fallback
  unlink(tmp)
})

test_that(".write_cleaned_vcf: SNP count in output matches input", {
  tmp <- tempfile(fileext = ".vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), tmp, verbose = FALSE)
  con <- gzcon(file(tmp, "rb"))
  lines <- readLines(con)
  close(con)
  data_lines <- lines[!startsWith(lines, "#")]
  expect_equal(length(data_lines), nrow(.si30))
  unlink(tmp)
})

test_that(".write_cleaned_vcf: round-trips dosage losslessly (no NAs)", {
  # Read back and verify 0/1/2 are recovered correctly
  tmp <- tempfile(fileext = ".vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), tmp, verbose = FALSE)
  con <- gzcon(file(tmp, "rb"))
  lines <- readLines(con)
  close(con)
  data_lines <- lines[!startsWith(lines, "#")]
  gt_map <- c("0/0" = 0L, "0/1" = 1L, "1/1" = 2L, "./." = NA_integer_)
  for (si in seq_len(min(5L, length(data_lines)))) {
    fields   <- strsplit(data_lines[si], "\t")[[1]]
    gt_calls <- fields[10:length(fields)]
    dosages  <- gt_map[gt_calls]
    # Find which SNP this is (by ID)
    snp_id   <- fields[3]
    col_idx  <- which(colnames(.G30) == snp_id)
    if (!length(col_idx)) next
    expected <- .G30[, col_idx]
    expect_equal(as.integer(dosages), as.integer(expected),
                 label = paste("SNP", snp_id, "dosage round-trip"))
  }
  unlink(tmp)
})

# ==============================================================================
# Section 2: phase_with_beagle() argument validation - no JAR required
# ==============================================================================

test_that("phase_with_beagle: missing input_vcf errors immediately", {
  expect_error(
    phase_with_beagle(input_vcf = "/nonexistent/path/geno.vcf",
                      out_prefix = tempfile()),
    "not found"
  )
})

test_that("phase_with_beagle: non-VCF input_vcf errors immediately", {
  tmp_csv <- tempfile(fileext = ".csv")
  writeLines("a,b,c", tmp_csv)
  expect_error(
    phase_with_beagle(input_vcf = tmp_csv, out_prefix = tempfile()),
    "vcf"
  )
  unlink(tmp_csv)
})

test_that("phase_with_beagle: invalid java_mem_gb errors immediately", {
  # Create a dummy VCF so the file-exists check passes
  tmp_vcf <- tempfile(fileext = ".vcf")
  writeLines(c("##fileformat=VCFv4.2", "#CHROM\tPOS"), tmp_vcf)
  expect_error(
    phase_with_beagle(input_vcf  = tmp_vcf,
                      out_prefix = tempfile(),
                      beagle_jar = "/dev/null",
                      java_mem_gb = -1),
    "java_mem_gb"
  )
  unlink(tmp_vcf)
})

test_that("phase_with_beagle: missing beagle_jar with no fallback errors", {
  # Write a minimal VCF so file-exists check passes
  tmp_vcf <- tempfile(fileext = ".vcf")
  writeLines(c("##fileformat=VCFv4.2",
               "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tind1"),
             tmp_vcf)
  # Use an out_dir where no beagle.jar exists
  out_dir <- tempfile(); dir.create(out_dir)
  expect_error(
    phase_with_beagle(input_vcf  = tmp_vcf,
                      out_prefix = file.path(out_dir, "test"),
                      beagle_jar = NULL),
    "beagle.jar not found"
  )
  unlink(tmp_vcf); unlink(out_dir, recursive = TRUE)
})

test_that("phase_with_beagle: rejects more than two threads", {
  tmp_vcf <- tempfile(fileext = ".vcf")
  writeLines(c(
    "##fileformat=VCFv4.2",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tind1"
  ), tmp_vcf)
  expect_error(
    phase_with_beagle(
      input_vcf = tmp_vcf, out_prefix = tempfile(),
      beagle_jar = tmp_vcf, nthreads = 3L
    ),
    "1 or 2"
  )
  unlink(tmp_vcf)
})

test_that("Beagle version parsing ignores dates embedded in JAR names", {
  expect_equal(
    HapBlockR:::.parse_beagle_version(
      "beagle.27Feb25.75f.jar (version 5.5)"
    ),
    "5.5"
  )
  expect_equal(
    HapBlockR:::.parse_beagle_version("Beagle 5.4"),
    "5.4"
  )
  expect_true(is.na(
    HapBlockR:::.parse_beagle_version("Using beagle.27Feb25.75f.jar")
  ))
})

test_that("Beagle VCF QC reports identity, concordance, and imputation", {
  input <- tempfile(fileext = ".vcf")
  output <- tempfile(fileext = ".vcf")
  header <- c(
    "##fileformat=VCFv4.2",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\ts1\ts2"
  )
  writeLines(c(
    header,
    "1\t100\trs1\tA\tT\t.\tPASS\t.\tGT\t0/1\t./."
  ), input)
  writeLines(c(
    header,
    "1\t100\trs1\tA\tT\t.\tPASS\t.\tGT\t0|1\t1|1"
  ), output)
  qc <- HapBlockR:::.compare_beagle_vcfs(input, output)
  expect_true(qc$sample_identity)
  expect_true(qc$variant_identity)
  expect_equal(qc$genotype_concordance, 1)
  expect_equal(qc$imputation_rate, 1)
  expect_equal(qc$missing_before, 1L)
  expect_equal(qc$missing_after, 0L)
  unlink(c(input, output))
})

test_that("Beagle VCF QC detects allele-identity changes", {
  input <- tempfile(fileext = ".vcf")
  output <- tempfile(fileext = ".vcf")
  header <- c(
    "##fileformat=VCFv4.2",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\ts1"
  )
  writeLines(c(header, "1\t100\trs1\tA\tT\t.\tPASS\t.\tGT\t0/1"), input)
  writeLines(c(header, "1\t100\trs1\tA\tG\t.\tPASS\t.\tGT\t0|1"), output)
  qc <- HapBlockR:::.compare_beagle_vcfs(input, output)
  expect_false(qc$variant_identity)
  unlink(c(input, output))
})

test_that("assess_phasing_accuracy reports truth-set switch and dosage metrics", {
  variant_ids <- paste0("s", 1:5)
  sample_ids <- c("P1", "P2")
  truth_h1 <- matrix(
    0,
    nrow = 5,
    ncol = 2,
    dimnames = list(variant_ids, sample_ids)
  )
  truth_h2 <- 1 - truth_h1
  truth <- list(
    hap1 = truth_h1,
    hap2 = truth_h2,
    snp_info = data.frame(
      SNP = variant_ids,
      CHR = "1",
      POS = seq_len(5),
      REF = "A",
      ALT = "G",
      stringsAsFactors = FALSE
    )
  )
  estimate_h1 <- truth_h1
  estimate_h2 <- truth_h2
  estimate_h1[3:5, "P1"] <- 1
  estimate_h2[3:5, "P1"] <- 0
  estimate_h1[, "P2"] <- 1
  estimate_h2[, "P2"] <- 0
  estimate <- truth
  estimate$hap1 <- estimate_h1
  estimate$hap2 <- estimate_h2

  accuracy <- assess_phasing_accuracy(
    truth,
    estimate,
    max_switch_error_rate = 0.2,
    min_dosage_accuracy = 1,
    min_allele_concordance = 0.8,
    min_call_rate = 1
  )

  expect_s3_class(accuracy, "HapBlockR_phasing_accuracy")
  expect_s3_class(accuracy, "hapblockr_result")
  expect_equal(accuracy$metrics$switches, 1)
  expect_equal(accuracy$metrics$transitions, 8)
  expect_equal(accuracy$metrics$switch_error_rate, 0.125)
  expect_equal(accuracy$metrics$dosage_accuracy, 1)
  expect_equal(accuracy$metrics$allele_concordance, 0.8)
  expect_true(all(accuracy$quality_control$passed))
  expect_silent(validate(accuracy))
})

test_that("assess_phasing_accuracy aligns identities and enforces gates", {
  variant_ids <- paste0("v", 1:4)
  sample_ids <- c("A", "B")
  hap1 <- matrix(
    c(0, 0, 1, 1, 1, 0, 1, 0),
    nrow = 4,
    dimnames = list(variant_ids, sample_ids)
  )
  truth <- list(
    hap1 = hap1,
    hap2 = 1 - hap1,
    snp_info = data.frame(
      SNP = variant_ids, CHR = "2", POS = 11:14,
      REF = "C", ALT = "T", stringsAsFactors = FALSE
    )
  )
  estimate <- truth
  estimate$hap1[3:4, "A"] <- 1 - estimate$hap1[3:4, "A"]
  estimate$hap2[3:4, "A"] <- 1 - estimate$hap2[3:4, "A"]
  estimate$hap1 <- estimate$hap1[4:1, 2:1, drop = FALSE]
  estimate$hap2 <- estimate$hap2[4:1, 2:1, drop = FALSE]
  estimate$snp_info <- estimate$snp_info[4:1, , drop = FALSE]

  report <- assess_phasing_accuracy(
    truth,
    estimate,
    max_switch_error_rate = 0,
    strict = FALSE
  )
  expect_false(report$metrics$sample_order_identity)
  expect_false(report$metrics$variant_order_identity)
  expect_false(report$quality_control$passed[
    report$quality_control$gate == "switch_error_rate"
  ])
  expect_error(
    assess_phasing_accuracy(
      truth,
      estimate,
      max_switch_error_rate = 0
    ),
    "switch_error_rate"
  )
})

test_that("phase_with_beagle validates a truth set before execution", {
  expect_error(
    phase_with_beagle(
      input_vcf = system.file(
        "extdata", "example_genotypes.vcf", package = "HapBlockR"
      ),
      out_prefix = tempfile("truth-validation-"),
      truth_vcf = tempfile("missing-truth-", fileext = ".vcf"),
      beagle_jar = tempfile("missing-beagle-", fileext = ".jar")
    ),
    "truth_vcf not found"
  )
})

# ==============================================================================
# Section 3: phase_with_beagle() + read_phased_vcf() - beagle.jar required
# ==============================================================================

test_that("phase_with_beagle: produces phased VCF.gz output file", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  # Write a clean input VCF from the 30-SNP subset
  tmp_dir  <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in   <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  out_prefix <- file.path(tmp_dir, "phased")
  result <- phase_with_beagle(
    input_vcf  = vcf_in,
    out_prefix = out_prefix,
    beagle_jar = .beagle_jar_path(),
    nthreads   = 1L,
    verbose    = FALSE
  )

  expect_type(result, "list")
  expect_true("output_vcf" %in% names(result))
  expect_true(file.exists(result$output_vcf))
  expect_true(grepl("\\.vcf\\.gz$", result$output_vcf))
})

test_that("phase_with_beagle: output VCF contains phased GTs (| separator)", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in  <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  result <- phase_with_beagle(
    input_vcf  = vcf_in,
    out_prefix = file.path(tmp_dir, "phased"),
    beagle_jar = .beagle_jar_path(),
    nthreads   = 1L,
    verbose    = FALSE
  )

  con <- gzcon(file(result$output_vcf, "rb"))
  lines <- readLines(con, n = 50L)
  close(con)
  data_lines <- lines[!startsWith(lines, "#")]
  expect_true(length(data_lines) > 0L)
  # At least one data line must use phased separator "|"
  has_pipe <- any(grepl("0|0|0|1|1|1", data_lines, fixed = TRUE) |
                    grepl("\\d\\|\\d", data_lines))
  expect_true(has_pipe, label = "Beagle output must use phased | separator")
})

test_that("phase_with_beagle: same SNP count in output as input", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in  <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  result <- phase_with_beagle(
    input_vcf  = vcf_in,
    out_prefix = file.path(tmp_dir, "phased"),
    beagle_jar = .beagle_jar_path(),
    nthreads   = 1L,
    verbose    = FALSE
  )

  con <- gzcon(file(result$output_vcf, "rb"))
  lines <- readLines(con)
  close(con)
  n_data <- sum(!startsWith(lines, "#"))
  expect_equal(n_data, nrow(.si30),
               label = "SNP count preserved after phasing")
})

test_that("phase_with_beagle then read_phased_vcf: returns valid phased list", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in  <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  result <- phase_with_beagle(
    input_vcf  = vcf_in,
    out_prefix = file.path(tmp_dir, "phased"),
    beagle_jar = .beagle_jar_path(),
    nthreads   = 1L,
    verbose    = FALSE
  )

  phased <- read_phased_vcf(result$output_vcf, verbose = FALSE)

  expect_type(phased, "list")
  expect_true(all(c("hap1","hap2","dosage","sample_ids","phased") %in% names(phased)))
  expect_true(phased$phased)
  expect_equal(ncol(phased$hap1), nrow(.G30))        # columns = individuals
  expect_equal(nrow(phased$hap1), nrow(.si30))       # rows = SNPs (may differ if Beagle drops monomorphics)
  expect_equal(phased$sample_ids, rownames(.G30))
})

test_that("read_phased_vcf: hap1 + hap2 == dosage for all non-missing entries", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in  <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  result <- phase_with_beagle(
    input_vcf  = vcf_in,
    out_prefix = file.path(tmp_dir, "phased"),
    beagle_jar = .beagle_jar_path(),
    nthreads   = 1L,
    verbose    = FALSE
  )

  phased <- read_phased_vcf(result$output_vcf, verbose = FALSE)

  # hap1 and hap2 are 0/1 matrices (gamete alleles); dosage = hap1 + hap2
  non_na <- !is.na(phased$hap1) & !is.na(phased$hap2) & !is.na(phased$dosage)
  sum_gametes <- phased$hap1[non_na] + phased$hap2[non_na]
  expect_equal(sum_gametes, phased$dosage[non_na],
               tolerance = 1e-10,
               label = "hap1 + hap2 must equal dosage for phased genotypes")
})

test_that("read_phased_vcf then extract_haplotypes: produces phased strings", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in  <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  result <- phase_with_beagle(
    input_vcf  = vcf_in,
    out_prefix = file.path(tmp_dir, "phased"),
    beagle_jar = .beagle_jar_path(),
    nthreads   = 1L,
    verbose    = FALSE
  )

  phased <- read_phased_vcf(result$output_vcf, verbose = FALSE)
  blk1   <- ldx_blocks[ldx_blocks$CHR == "1", ][1, ]

  haps_phased <- extract_haplotypes(phased, .si30, blk1, min_snps = 3L)
  expect_true(length(haps_phased) >= 1L)
  # All strings must contain "|"
  expect_true(all(grepl("|", haps_phased[[1]], fixed = TRUE)))
  # block_info$phased must be TRUE
  expect_true(all(attr(haps_phased, "block_info")$phased))
})

test_that("phase_with_beagle: seed argument produces reproducible output", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  vcf_in  <- file.path(tmp_dir, "input.vcf.gz")
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  r1 <- phase_with_beagle(input_vcf = vcf_in,
                          out_prefix = file.path(tmp_dir, "run1"),
                          beagle_jar = .beagle_jar_path(),
                          nthreads = 1L, seed = 42L, verbose = FALSE)
  r2 <- phase_with_beagle(input_vcf = vcf_in,
                          out_prefix = file.path(tmp_dir, "run2"),
                          beagle_jar = .beagle_jar_path(),
                          nthreads = 1L, seed = 42L, verbose = FALSE)

  # Read both phased VCFs and compare dosage matrices
  p1 <- read_phased_vcf(r1$output_vcf, verbose = FALSE)
  p2 <- read_phased_vcf(r2$output_vcf, verbose = FALSE)
  expect_equal(p1$hap1,    p2$hap1,    label = "hap1 reproducible with same seed")
  expect_equal(p1$hap2,    p2$hap2,    label = "hap2 reproducible with same seed")
  expect_equal(p1$dosage,  p2$dosage,  label = "dosage reproducible with same seed")
})

# ==============================================================================
# Section 4: run_ldx_pipeline(phase=TRUE) - beagle.jar required
# ==============================================================================

test_that("run_ldx_pipeline phase=TRUE: returns phased haplotypes list", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  f <- system.file("extdata", "example_genotypes.vcf",
                   package = "HapBlockR")
  skip_if(!file.exists(f), "example VCF not found")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)

  # Copy beagle.jar to out_dir (auto-discovery path)
  file.copy(.beagle_jar_path(), file.path(tmp_dir, "beagle.jar"))

  res <- run_ldx_pipeline(
    geno_source    = f,
    out_dir        = tmp_dir,
    out_blocks     = file.path(tmp_dir, "blocks.csv"),
    out_diversity  = file.path(tmp_dir, "diversity.csv"),
    out_hap_matrix = file.path(tmp_dir, "hap_matrix.csv"),
    CLQcut         = 0.5,
    leng           = 10L,
    subSegmSize    = 80L,
    min_snps_block = 3L,
    phase          = TRUE,
    verbose        = FALSE
  )

  expect_true(all(c("blocks","diversity","hap_matrix","haplotypes",
                    "geno_matrix","beagle_geno_matrix",
                    "snp_info_filtered") %in% names(res)))
  expect_s3_class(res$blocks, "data.frame")
  expect_true(nrow(res$blocks) >= 1L)

  # haplotypes must be from phased input (strings contain "|")
  bi <- attr(res$haplotypes, "block_info")
  expect_true(any(bi$phased))
  first_block <- res$haplotypes[[1]]
  expect_true(all(grepl("|", first_block, fixed = TRUE)),
              label = "pipeline phase=TRUE must produce phased haplotype strings")
})

test_that("run_ldx_pipeline phase=TRUE: phased hap1+hap2=dosage invariant holds", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  f <- system.file("extdata", "example_genotypes.vcf",
                   package = "HapBlockR")
  skip_if(!file.exists(f), "example VCF not found")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  file.copy(.beagle_jar_path(), file.path(tmp_dir, "beagle.jar"))

  res <- run_ldx_pipeline(
    geno_source    = f,
    out_dir        = tmp_dir,
    out_blocks     = file.path(tmp_dir, "blocks.csv"),
    out_diversity  = file.path(tmp_dir, "diversity.csv"),
    out_hap_matrix = file.path(tmp_dir, "hap_matrix.csv"),
    CLQcut         = 0.5, leng = 10L, subSegmSize = 80L,
    min_snps_block = 3L,
    phase          = TRUE,
    verbose        = FALSE
  )

  # Check first block: gamete strings sum to dosage at each SNP
  bi   <- attr(res$haplotypes, "block_info")
  b1   <- res$haplotypes[[1]]
  # Parse "g1string|g2string" for a few individuals
  for (ind in head(seq_along(b1), 5L)) {
    parts <- strsplit(b1[ind], "|", fixed = TRUE)[[1]]
    expect_equal(length(parts), 2L)
    g1 <- as.integer(strsplit(parts[1], "")[[1]])
    g2 <- as.integer(strsplit(parts[2], "")[[1]])
    dos <- g1 + g2
    expect_true(all(dos %in% 0:2),
                label = paste("ind", ind, "dosage range"))
  }
})

test_that("run_ldx_pipeline phase=TRUE: second call reuses cached phased VCF", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  f <- system.file("extdata", "example_genotypes.vcf",
                   package = "HapBlockR")
  skip_if(!file.exists(f), "example VCF not found")

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  file.copy(.beagle_jar_path(), file.path(tmp_dir, "beagle.jar"))

  common_args <- list(
    geno_source    = f, out_dir = tmp_dir,
    out_blocks     = file.path(tmp_dir, "blocks.csv"),
    out_diversity  = file.path(tmp_dir, "diversity.csv"),
    out_hap_matrix = file.path(tmp_dir, "hap_matrix.csv"),
    CLQcut = 0.5, leng = 10L, subSegmSize = 80L,
    min_snps_block = 3L, phase = TRUE, verbose = FALSE
  )
  do.call(run_ldx_pipeline, common_args)  # first run: builds cache
  # Second run must not error (cache reuse path)
  expect_no_error(do.call(run_ldx_pipeline, common_args))
})

test_that("run_ldx_pipeline: beagle_geno_matrix is NULL when phase = FALSE", {
  vcf_in <- tempfile(fileext = ".vcf.gz")
  on.exit(unlink(vcf_in), add = TRUE)
  .wcv(.G30, .si30, rownames(.G30), vcf_in, verbose = FALSE)

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)

  res <- run_ldx_pipeline(
    geno_source    = vcf_in,
    out_dir        = tmp_dir,
    out_blocks     = file.path(tmp_dir, "blocks.csv"),
    out_diversity  = file.path(tmp_dir, "diversity.csv"),
    out_hap_matrix = file.path(tmp_dir, "hap_matrix.csv"),
    CLQcut         = 0.5, leng = 10L, subSegmSize = 80L,
    min_snps_block = 3L,
    phase          = FALSE,
    verbose        = FALSE
  )

  expect_true("beagle_geno_matrix" %in% names(res))
  expect_null(res$beagle_geno_matrix)
})

test_that("run_ldx_pipeline phase=TRUE: beagle_geno_matrix reflects genuine Beagle imputation", {
  skip_if(!.beagle_works(), "Beagle not functional (check java PATH and beagle.jar)")

  # The packaged example datasets/VCFs contain no missing genotypes, so
  # inject real missingness into a copy of the shared 30-SNP fixture to
  # give Beagle genuine missing calls to impute (not just re-phase).
  G_miss <- .G30
  set.seed(99L)
  miss_idx <- cbind(
    row = sample(seq_len(nrow(G_miss)), 8L),
    col = sample(seq_len(ncol(G_miss)), 8L)
  )
  for (k in seq_len(nrow(miss_idx)))
    G_miss[miss_idx[k, "row"], miss_idx[k, "col"]] <- NA
  expect_equal(sum(is.na(G_miss)), 8L)

  vcf_in <- tempfile(fileext = ".vcf.gz")
  on.exit(unlink(vcf_in), add = TRUE)
  .wcv(G_miss, .si30, rownames(G_miss), vcf_in, verbose = FALSE)

  tmp_dir <- tempfile(); dir.create(tmp_dir)
  on.exit(unlink(tmp_dir, recursive = TRUE), add = TRUE)
  file.copy(.beagle_jar_path(), file.path(tmp_dir, "beagle.jar"))

  res <- run_ldx_pipeline(
    geno_source    = vcf_in,
    out_dir        = tmp_dir,
    out_blocks     = file.path(tmp_dir, "blocks.csv"),
    out_diversity  = file.path(tmp_dir, "diversity.csv"),
    out_hap_matrix = file.path(tmp_dir, "hap_matrix.csv"),
    CLQcut         = 0.5, leng = 10L, subSegmSize = 80L,
    min_snps_block = 3L,
    phase          = TRUE,
    verbose        = FALSE
  )

  expect_true("beagle_geno_matrix" %in% names(res))
  expect_false(is.null(res$beagle_geno_matrix))

  bgm <- res$beagle_geno_matrix
  gm  <- res$geno_matrix

  expect_true(is.matrix(bgm))
  expect_equal(nrow(bgm), nrow(gm))
  expect_equal(sort(rownames(bgm)), sort(rownames(gm)))
  expect_true(all(colnames(bgm) %in% colnames(gm)))

  # Beagle must have filled in every missing call - no residual NA.
  expect_equal(sum(is.na(bgm)), 0L)

  # At the cells that were genuinely missing going in, Beagle's HMM-based
  # imputation (local haplotype structure) should differ from the naive
  # per-column mean/mode fallback used for geno_matrix for at least one
  # cell - proving beagle_geno_matrix is not simply a copy of geno_matrix.
  common_ids  <- intersect(rownames(bgm), rownames(gm))
  common_snps <- intersect(colnames(bgm), colnames(gm))
  diffs <- vapply(seq_len(nrow(miss_idx)), function(k) {
    r  <- rownames(G_miss)[miss_idx[k, "row"]]
    cn <- colnames(G_miss)[miss_idx[k, "col"]]
    if (!(r %in% common_ids) || !(cn %in% common_snps)) return(NA)
    bgm[r, cn] != gm[r, cn]
  }, logical(1))
  expect_true(sum(!is.na(diffs)) >= 1L,
              label = "at least one originally-missing cell must survive filtering for comparison")
  expect_true(any(diffs, na.rm = TRUE),
              label = "beagle_geno_matrix must differ from geno_matrix's mean/mode fallback for at least one originally-missing cell")
})

# ==============================================================================
# Section 5: read_phased_vcf() on hand-crafted VCFs - no JAR required
# ==============================================================================

# Helper: write a minimal phased VCF.gz
.write_hand_phased_vcf <- function(n_snp = 5L, n_ind = 10L, seed = 1L) {
  set.seed(seed)
  ind_ids <- paste0("ind", seq_len(n_ind))
  snp_ids <- paste0("rs", seq_len(n_snp))
  pos     <- seq(1000L, by = 1000L, length.out = n_snp)

  # Random phased genotypes
  h1 <- matrix(sample(0:1, n_snp * n_ind, replace = TRUE), n_snp, n_ind)
  h2 <- matrix(sample(0:1, n_snp * n_ind, replace = TRUE), n_snp, n_ind)
  gt_mat <- matrix(paste0(h1, "|", h2), n_snp, n_ind)

  tmp <- tempfile(fileext = ".vcf.gz")
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    paste(c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT",
            ind_ids), collapse = "\t")
  ), con)
  for (i in seq_len(n_snp)) {
    writeLines(paste(c("1", pos[i], snp_ids[i], "A", "T", ".", "PASS", ".", "GT",
                       gt_mat[i, ]), collapse = "\t"), con)
  }
  close(con)
  list(path = tmp, h1 = h1, h2 = h2, ind_ids = ind_ids, snp_ids = snp_ids)
}

test_that("read_phased_vcf: returns required list elements", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  expect_true(all(c("hap1","hap2","dosage","sample_ids","phased") %in% names(phased)))
  expect_true(phased$phased)
})

test_that("read_phased_vcf: hap1 and hap2 contain only 0/1/NA", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  h1_vals <- as.integer(phased$hap1[!is.na(phased$hap1)])
  h2_vals <- as.integer(phased$hap2[!is.na(phased$hap2)])
  expect_true(all(h1_vals %in% 0:1))
  expect_true(all(h2_vals %in% 0:1))
})

test_that("read_phased_vcf: sample_ids match header order", {
  n_ind <- 8L
  vf <- .write_hand_phased_vcf(n_ind = n_ind)
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  expect_equal(phased$sample_ids, vf$ind_ids)
})

test_that("read_phased_vcf: hap1 matches hand-crafted gamete matrix", {
  vf <- .write_hand_phased_vcf(n_snp = 5L, n_ind = 10L, seed = 7L)
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  # hap1 is SNPs x individuals; compare to vf$h1
  expect_equal(as.integer(phased$hap1), as.integer(vf$h1),
               label = "read_phased_vcf hap1 matches hand-crafted values")
})

test_that("read_phased_vcf: dosage = hap1 + hap2 for all non-missing", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  non_na <- !is.na(phased$hap1) & !is.na(phased$hap2) & !is.na(phased$dosage)
  expect_equal(phased$hap1[non_na] + phased$hap2[non_na],
               phased$dosage[non_na], tolerance = 1e-10)
})

test_that("read_phased_vcf: dimensions correct (SNPs x individuals)", {
  n_snp <- 7L; n_ind <- 12L
  vf <- .write_hand_phased_vcf(n_snp = n_snp, n_ind = n_ind)
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  expect_equal(nrow(phased$hap1),  n_snp)
  expect_equal(ncol(phased$hap1),  n_ind)
  expect_equal(nrow(phased$hap2),  n_snp)
  expect_equal(nrow(phased$dosage), n_snp)
})

test_that("read_phased_vcf: missing GT (./.) encoded as NA", {
  # Write a VCF with one missing GT
  tmp <- tempfile(fileext = ".vcf.gz")
  ind_ids <- c("ind1","ind2","ind3")
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    paste(c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT",
            ind_ids), collapse="\t"),
    paste(c("1","1000","rs1","A","T",".","PASS",".","GT",
            "0|1", "./.", "1|0"), collapse="\t")
  ), con)
  close(con)
  on.exit(unlink(tmp))
  phased <- read_phased_vcf(tmp, verbose = FALSE)
  # Second individual (index 2) should have NA for hap1 and hap2
  expect_true(is.na(phased$hap1[1, 2]))
  expect_true(is.na(phased$hap2[1, 2]))
  expect_true(is.na(phased$dosage[1, 2]))
  # First and third individuals should not be NA
  expect_false(is.na(phased$hap1[1, 1]))
  expect_false(is.na(phased$hap1[1, 3]))
})

test_that("read_phased_vcf: min_maf=0.5 filters low-MAF variants", {
  # All variants have MAF = 0.1 (1 het out of 10)
  # min_maf = 0.5 should filter them all out
  tmp <- tempfile(fileext = ".vcf.gz")
  n_ind <- 10L
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    paste(c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT",
            paste0("ind", 1:n_ind)), collapse="\t"),
    # SNP 1: MAF = 1/20 = 0.05 (one 0|1, rest 0|0)
    paste(c("1","1000","rs1","A","T",".","PASS",".","GT",
            "0|1", rep("0|0", n_ind - 1L)), collapse="\t"),
    # SNP 2: MAF = 0.5 (half individuals are 1|1, half are 0|0 -> 10 ALT of 20 alleles)
    paste(c("1","2000","rs2","A","T",".","PASS",".","GT",
            rep(c("1|1","0|0"), n_ind / 2L)), collapse="\t")
  ), con)
  close(con)
  on.exit(unlink(tmp))

  phased_lo <- read_phased_vcf(tmp, min_maf = 0.0, verbose = FALSE)
  phased_hi <- read_phased_vcf(tmp, min_maf = 0.3, verbose = FALSE)
  expect_equal(nrow(phased_lo$hap1), 2L)   # both SNPs retained
  expect_equal(nrow(phased_hi$hap1), 1L)   # only SNP 2 (MAF=0.5) retained
})

test_that("read_phased_vcf: chr normalisation strips 'chr' prefix", {
  tmp <- tempfile(fileext = ".vcf.gz")
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tind1",
    "chr1\t1000\trs1\tA\tT\t.\tPASS\t.\tGT\t0|1"
  ), con)
  close(con)
  on.exit(unlink(tmp))
  phased <- read_phased_vcf(tmp, verbose = FALSE)
  # The CHR stored in snp_info should be "1" not "chr1"
  if (!is.null(phased$snp_info)) {
    expect_true(all(!grepl("^chr", phased$snp_info$CHR, ignore.case = TRUE)),
                label = "chr prefix should be stripped from chromosome labels")
  }
  expect_equal(nrow(phased$hap1), 1L)
})

test_that("read_phased_vcf: dot IDs synthesised as CHR_POS (prevents duplicate rownames)", {
  # Standard VCFs often have '.' in the ID column. Beagle preserves whatever
  # ID was in the input, so a user-supplied externally phased VCF may arrive
  # with all-dot IDs. Without the fix, rownames(hap1) would all be '.' and
  # extract_haplotypes() would fail when slicing by SNP name.
  tmp <- tempfile(fileext = ".vcf.gz")
  n_ind <- 6L; n_snp <- 5L
  ind_ids <- paste0("ind", seq_len(n_ind))
  con <- gzcon(file(tmp, "wb"))
  header <- paste(c("#CHROM","POS","ID","REF","ALT","QUAL","FILTER","INFO","FORMAT",
                    ind_ids), collapse="\t")
  lines <- c("##fileformat=VCFv4.2",
             "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
             header)
  set.seed(42L)
  pos_vals <- seq(1000L, by=1000L, length.out=n_snp)
  for (i in seq_len(n_snp)) {
    gts <- paste(sample(c("0|0","0|1","1|0","1|1"), n_ind, replace=TRUE), collapse="\t")
    lines <- c(lines, paste(c("1", pos_vals[i], ".", "A", "T", ".", "PASS", ".", "GT", gts),
                            collapse="\t"))
  }
  writeLines(lines, con); close(con)
  on.exit(unlink(tmp))

  phased <- read_phased_vcf(tmp, verbose = FALSE)

  # Core check: no duplicate rownames
  rn <- rownames(phased$hap1)
  expect_equal(length(unique(rn)), n_snp,
               label = "All SNP rownames must be unique after dot-ID synthesis")

  # Synthesised IDs must follow the CHR_POS pattern
  expect_true(all(grepl("^1_\\d+$", rn)),
              label = "Synthesised IDs must be CHR_POS format")

  # snp_info$SNP must also use the synthesised IDs
  expect_equal(phased$snp_info$SNP, rn,
               label = "snp_info$SNP must match rownames of hap1")

  # Dimensions still correct
  expect_equal(nrow(phased$hap1), n_snp)
  expect_equal(ncol(phased$hap1), n_ind)
})

test_that("read_phased_vcf: empty string IDs also synthesised as CHR_POS", {
  # Some VCF writers emit an empty string instead of "." for missing IDs.
  tmp <- tempfile(fileext = ".vcf.gz")
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tind1\tind2",
    "2\t5000\t\tG\tC\t.\tPASS\t.\tGT\t0|1\t1|1",  # empty ID
    "2\t6000\t\tA\tT\t.\tPASS\t.\tGT\t0|0\t0|1"   # empty ID
  ), con)
  close(con)
  on.exit(unlink(tmp))
  phased <- read_phased_vcf(tmp, verbose = FALSE)
  rn <- rownames(phased$hap1)
  expect_equal(length(unique(rn)), 2L)
  expect_true(all(grepl("^2_\\d+$", rn)))
})

test_that("read_phased_vcf: mixed real and dot IDs - only dot rows synthesised", {
  tmp <- tempfile(fileext = ".vcf.gz")
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tind1",
    "1\t1000\trs123\tA\tT\t.\tPASS\t.\tGT\t0|1",   # real ID kept
    "1\t2000\t.\tG\tC\t.\tPASS\t.\tGT\t1|0",        # dot -> synthesise
    "1\t3000\trs456\tA\tG\t.\tPASS\t.\tGT\t0|0"    # real ID kept
  ), con)
  close(con)
  on.exit(unlink(tmp))
  phased <- read_phased_vcf(tmp, verbose = FALSE)
  rn <- rownames(phased$hap1)
  expect_equal(rn[1], "rs123",  label = "real ID rs123 preserved")
  expect_equal(rn[2], "1_2000", label = "dot ID synthesised as CHR_POS")
  expect_equal(rn[3], "rs456",  label = "real ID rs456 preserved")
  expect_equal(length(unique(rn)), 3L)
})

# ==============================================================================
# Section 6: tests for code changes from review (haplotypes.R fixes)
# ==============================================================================

# -- Fix 1: unphase_to_dosage() returns individuals x SNPs -------------------

test_that("unphase_to_dosage: returns individuals x SNPs (transposed)", {
  vf <- .write_hand_phased_vcf(n_snp = 8L, n_ind = 12L)
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  dos <- HapBlockR:::unphase_to_dosage(phased)
  # hap1/hap2 are SNPs x individuals; unphase_to_dosage must return individuals x SNPs
  expect_equal(nrow(dos), 12L, label = "rows must be individuals")
  expect_equal(ncol(dos), 8L,  label = "cols must be SNPs")
})

test_that("unphase_to_dosage: values in {0,1,2,NA}", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  phased <- read_phased_vcf(vf$path, verbose = FALSE)
  dos <- HapBlockR:::unphase_to_dosage(phased)
  vals <- as.integer(dos[!is.na(dos)])
  expect_true(all(vals %in% 0:2))
})

# -- Fix 2: min_maf validation -----------------------------------------------

test_that("read_phased_vcf: min_maf > 0.5 errors", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  expect_error(read_phased_vcf(vf$path, min_maf = 0.6, verbose = FALSE),
               "min_maf")
})

test_that("read_phased_vcf: min_maf = NA errors", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  expect_error(read_phased_vcf(vf$path, min_maf = NA_real_, verbose = FALSE),
               "min_maf")
})

test_that("read_phased_vcf: min_maf = 'high' errors", {
  vf <- .write_hand_phased_vcf()
  on.exit(unlink(vf$path))
  expect_error(read_phased_vcf(vf$path, min_maf = "high", verbose = FALSE),
               "min_maf")
})

# -- Fix 3: GT parsing handles FORMAT subfields ------------------------------

test_that("read_phased_vcf: GT with FORMAT subfields (0|1:35:99) parsed correctly", {
  # Some VCFs (e.g. from GATK) include extra FORMAT fields like DP and GQ
  # The function must strip ":..." and parse only the GT portion
  tmp <- tempfile(fileext = ".vcf.gz")
  con <- gzcon(file(tmp, "wb"))
  writeLines(c(
    "##fileformat=VCFv4.2",
    "##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",
    "##FORMAT=<ID=DP,Number=1,Type=Integer,Description=\"Depth\">",
    "#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tind1\tind2\tind3",
    "1\t1000\trs1\tA\tT\t.\tPASS\t.\tGT:DP\t0|1:35\t1|1:20\t0|0:40"
  ), con)
  close(con)
  on.exit(unlink(tmp))
  phased <- read_phased_vcf(tmp, verbose = FALSE)
  expect_equal(nrow(phased$hap1), 1L)
  expect_equal(ncol(phased$hap1), 3L)
  # ind1: 0|1 -> hap1=0, hap2=1
  expect_equal(as.integer(phased$hap1[1, 1]), 0L)
  expect_equal(as.integer(phased$hap2[1, 1]), 1L)
  # ind2: 1|1 -> hap1=1, hap2=1
  expect_equal(as.integer(phased$hap1[1, 2]), 1L)
  expect_equal(as.integer(phased$hap2[1, 2]), 1L)
  # ind3: 0|0 -> hap1=0, hap2=0
  expect_equal(as.integer(phased$hap1[1, 3]), 0L)
  expect_equal(as.integer(phased$hap2[1, 3]), 0L)
})

# -- Fix 7: empty haplotypes in build_haplotype_feature_matrix ---------------

test_that("build_haplotype_feature_matrix: empty list returns zero-row result", {
  res <- build_haplotype_feature_matrix(list(), top_n = 5L, min_freq = 0.05)
  expect_true(is.list(res))
  expect_true("matrix" %in% names(res) && "info" %in% names(res))
  expect_equal(nrow(res$matrix), 0L)
  expect_equal(ncol(res$matrix), 0L)
  expect_equal(nrow(res$info),   0L)
})

# -- Fix 10: compute_haplotype_grm handles all-NA and monomorphic columns ----

test_that("compute_haplotype_grm: all-NA column removed without error", {
  M <- matrix(c(0, 1, 0, 2, 1, 2,
                NA, NA, NA, NA, NA, NA), nrow = 6, ncol = 2)
  colnames(M) <- c("hap_a", "hap_b_all_na")
  # Should not error; all-NA column dropped, GRM computed from remaining column
  expect_no_error(compute_haplotype_grm(M, phased = FALSE))
})

test_that("compute_haplotype_grm: monomorphic column removed without error", {
  set.seed(1L)
  M <- matrix(c(sample(0:2, 20, replace = TRUE),
                rep(0L, 20)),    # monomorphic column
              nrow = 20, ncol = 2)
  colnames(M) <- c("hap_poly", "hap_mono")
  expect_no_error(compute_haplotype_grm(M, phased = FALSE))
})

test_that("compute_haplotype_grm: all columns NA errors with clear message", {
  M <- matrix(NA_real_, nrow = 5, ncol = 3)
  colnames(M) <- paste0("h", 1:3)
  expect_error(compute_haplotype_grm(M, phased = FALSE), "NA")
})

# -- Fix 13: extract_haplotypes required-column validation -------------------

test_that("extract_haplotypes: missing SNP column in snp_info errors clearly", {
  si_bad <- .si30[, c("CHR", "POS")]   # missing SNP
  expect_error(
    extract_haplotypes(.G30, si_bad, ldx_blocks[ldx_blocks$CHR == "1", ][1, ]),
    "SNP"
  )
})

test_that("extract_haplotypes: missing start.bp column in blocks errors clearly", {
  blk_bad <- ldx_blocks[ldx_blocks$CHR == "1", ][1, ]
  blk_bad$start.bp <- NULL  # remove column
  expect_error(
    extract_haplotypes(.G30, .si30, blk_bad),
    "start.bp"
  )
})
