## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  fig.width = 7,
  fig.height = 4,
  message   = FALSE,
  warning   = FALSE
)
library(HapBlockR)
data(ldx_geno,     package = "HapBlockR")
data(ldx_snp_info, package = "HapBlockR")
data(ldx_blocks,   package = "HapBlockR")
data(ldx_gwas,     package = "HapBlockR")

## ----example-data-------------------------------------------------------------
dim(ldx_geno)             # 120 individuals x 230 SNPs
head(ldx_snp_info)        # SNP, CHR, POS, REF, ALT
table(ldx_snp_info$CHR)   # chr1, chr2, chr3
nrow(ldx_gwas)            # toy GWAS markers

## ----read-formats, eval=FALSE-------------------------------------------------
# be_vcf <- read_geno("mydata.vcf.gz")
# be_csv <- read_geno("mydata.csv")
# be_hmp <- read_geno("mydata.hmp.txt")
# be_gds <- read_geno("mydata.gds")
# be_bed <- read_geno("mydata.bed")

## ----read-matrix--------------------------------------------------------------
be <- read_geno(ldx_geno, format = "matrix", snp_info = ldx_snp_info)
be

## ----backend-interface--------------------------------------------------------
be$n_samples
be$n_snps
be$sample_ids[1:4]
head(be$snp_info)
chunk <- read_chunk(be, 1:30)
dim(chunk)
close_backend(be)

## ----blues-vector, eval=FALSE-------------------------------------------------
# # Format 1: Named numeric vector
# blues <- c(ind001 = 4.21, ind002 = 3.87, ind003 = 5.14)
# 
# # Format 2: Data frame, single trait
# blues <- read.csv("blues.csv")
# res   <- run_haplotype_prediction(geno, snp_info, blocks,
#                                    blues    = blues,
#                                    id_col   = "Genotype",
#                                    blue_col = "YLD_BLUE")
# 
# # Format 3: Data frame, multiple traits
# res_mt <- run_haplotype_prediction(geno, snp_info, blocks,
#                                     blues     = blues_mt,
#                                     id_col    = "id",
#                                     blue_cols = c("YLD", "DIS", "PHT"))
# 
# # Format 4: Named list (different individuals per trait)
# blues <- list(
#   YLD = c(ind001 = 4.21, ind002 = 3.87),
#   DIS = c(ind001 = 0.32, ind003 = 0.28)
# )

## ----blues-extdata------------------------------------------------------------
blues_file <- system.file("extdata", "example_blues.csv", package = "HapBlockR")
blues      <- read.csv(blues_file)
head(blues, 3)

## ----run-all-chr--------------------------------------------------------------
blocks <- run_Big_LD_all_chr(
  ldx_geno,
  snp_info    = ldx_snp_info,
  method      = "r2",
  CLQcut      = 0.55,
  leng        = 15L,
  subSegmSize = 100L,
  n_threads   = 1L,
  verbose     = FALSE
)
nrow(blocks)
head(blocks)

## ----big-ld-single------------------------------------------------------------
blocks_chr1 <- run_Big_LD_all_chr(
  ldx_geno,
  snp_info    = ldx_snp_info,
  method      = "r2",
  CLQcut      = 0.55,
  leng        = 15L,
  subSegmSize = 100L,
  chr         = "1",
  n_threads   = 1L,
  verbose     = FALSE
)
nrow(blocks_chr1)
unique(blocks_chr1$CHR)

## ----wgs-accel, eval=FALSE----------------------------------------------------
# blocks_wgs <- run_Big_LD_all_chr(
#   be,
#   CLQmode         = "Leiden",
#   max_bp_distance = 500000L,
#   CLQcut          = 0.70,
#   subSegmSize     = 500L,
#   leng            = 50L,
#   checkLargest    = TRUE,
#   n_threads       = n_threads
# )

## ----summarise----------------------------------------------------------------
summarise_blocks(blocks)

## ----plot, fig.cap="LD block structure coloured by block size"----------------
if (requireNamespace("ggplot2", quietly = TRUE)) {
  print(plot_ld_blocks(blocks, colour_by = "length_bp", mb_scale = TRUE))
}

## ----haplotypes-unphased------------------------------------------------------
haps <- extract_haplotypes(
  geno     = ldx_geno,
  snp_info = ldx_snp_info,
  blocks   = blocks,
  min_snps = 5L,
  na_char  = "."
)
length(haps)
attr(haps, "block_info")
head(haps[[1]])

## ----diversity----------------------------------------------------------------
div <- compute_haplotype_diversity(haps)
head(div)

## ----diversity-plot, fig.cap="Expected heterozygosity per LD block"-----------
if (requireNamespace("ggplot2", quietly = TRUE)) {
  ggplot2::ggplot(div, ggplot2::aes(x = block_id, y = He)) +
    ggplot2::geom_col(fill = "#1D9E75") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle=90, size=8)) +
    ggplot2::labs(x=NULL, y="He", title="Haplotype diversity per LD block")
}

## ----qtl-regions--------------------------------------------------------------
qtl <- define_qtl_regions(
  gwas_results = ldx_gwas,
  blocks       = blocks,
  snp_info     = ldx_snp_info,
  p_threshold  = 5e-8,
  trait_col    = "trait"
)
head(qtl[, c("block_id","CHR","n_snps_block","n_sig_markers",
             "lead_marker","traits","pleiotropic")])
subset(qtl, pleiotropic)

## ----features-----------------------------------------------------------------
feat_add <- build_haplotype_feature_matrix(
  haplotypes = haps,
  top_n      = 5L,
  encoding   = "additive_012",
  scale_features = TRUE
)$matrix
dim(feat_add)

## ----hap-grm------------------------------------------------------------------
G_hap <- tcrossprod(feat_add) / ncol(feat_add)
dim(G_hap)
round(range(diag(G_hap)), 3)

## ----tuning-------------------------------------------------------------------
grid <- expand.grid(
  CLQcut = c(0.45, 0.55, 0.65), clstgap = 1e5, leng = 15,
  subSegmSize = 100, split = FALSE, checkLargest = FALSE,
  MAFcut = 0.05, CLQmode = "Density", kin_method = "chol",
  digits = -1, appendrare = FALSE, stringsAsFactors = FALSE
)

result <- tune_LD_params(
  geno_matrix    = ldx_geno,
  snp_info       = ldx_snp_info,
  gwas_df        = ldx_gwas,
  grid           = grid,
  prefer_perfect = TRUE,
  target_bp_band = c(5e4, 5e5),
  seed           = 42L
)
result$best_params
result$score_table[, c("CLQcut","n_unassigned","n_forced","n_blocks")]

## ----cv-prediction, eval=FALSE------------------------------------------------
# cv <- cv_haplotype_prediction(
#   geno_matrix = ldx_geno,
#   snp_info    = ldx_snp_info,
#   blocks      = blocks,
#   blues       = blues,
#   k           = 5L,
#   n_rep       = 3L,
#   id_col      = "id",
#   blue_col    = "YLD",
#   verbose     = FALSE
# )
# cv$pa_mean

## ----pop-compare, eval=FALSE--------------------------------------------------
# ids <- rownames(ldx_geno)
# cmp <- compare_haplotype_populations(
#   haplotypes  = haps,
#   group1      = ids[1:60],
#   group2      = ids[61:120],
#   group1_name = "cycle1",
#   group2_name = "cycle2"
# )
# cmp[cmp$divergent, c("block_id", "FST", "max_freq_diff", "chisq_p")]

## ----harmonise, eval=FALSE----------------------------------------------------
# haps_ref  <- extract_haplotypes(ref_geno, ldx_snp_info, blocks)
# haps_ref  <- collapse_haplotypes(haps_ref, min_freq = 0.05, collapse = "nearest")
# haps_tgt  <- extract_haplotypes(val_geno, ldx_snp_info, blocks)
# haps_harm <- harmonize_haplotypes(haps_tgt, haps_ref, max_hamming = 3L)
# attr(haps_harm, "harmonization_report")
# dip <- infer_block_haplotypes(haps_harm)
# head(dip[, c("block_id","id","diplotype","heterozygous","phase_ambiguous")])

## ----export-effects, eval=FALSE-----------------------------------------------
# export_candidate_regions(qtl, format = "bed", chr_prefix = "chr",
#                           out_file = "candidate_regions.bed")
# 
# allele_tbl <- decompose_block_effects(haps, ldx_snp_info, blocks,
#                                        snp_effects = pred$snp_effects[[1]])
# head(allele_tbl[order(-allele_tbl$allele_effect), ])
# 
# scan <- scan_diversity_windows(ldx_geno, ldx_snp_info,
#                                 window_bp = 50000L, step_bp = 25000L)

## ----stacking, eval=FALSE-----------------------------------------------------
# pred <- run_haplotype_prediction(
#   geno_matrix = ldx_geno, snp_info = ldx_snp_info, blocks = blocks,
#   blues = blues_vec, verbose = FALSE
# )
# ae <- decompose_block_effects(
#   haplotypes = haps, snp_info = ldx_snp_info,
#   blocks = blocks, snp_effects = pred$snp_effects[[1]]
# )
# scores <- score_favorable_haplotypes(haps, allele_effects = ae, normalize = TRUE)
# head(scores[, c("id","stacking_index","n_blocks_scored","rank")], 10)
# top10  <- scores$id[scores$rank <= 10]
# inv    <- summarize_parent_haplotypes(haps, candidate_ids = top10,
#                                        allele_effects = ae, min_freq = 0.02)
# inv[inv$dosage > 0 & inv$is_rare & !is.na(inv$allele_effect) & inv$allele_effect > 0,
#     c("id","block_id","allele","dosage","allele_freq","allele_effect")]

