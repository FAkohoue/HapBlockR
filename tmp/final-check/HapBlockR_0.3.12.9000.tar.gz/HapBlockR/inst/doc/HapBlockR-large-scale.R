## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)
library(HapBlockR)
set.seed(42)

## ----thread-equality----------------------------------------------------------
data(ldx_geno)
x <- ldx_geno[seq_len(min(40L, nrow(ldx_geno))),
              seq_len(min(30L, ncol(ldx_geno))), drop = FALSE]

r_one <- compute_r2(x, n_threads = 1)
r_two <- compute_r2(x, n_threads = 2)

stopifnot(isTRUE(all.equal(r_one, r_two, tolerance = 1e-12)))
dim(r_one)

## ----gds, eval=FALSE----------------------------------------------------------
# library(SNPRelate)
# 
# SNPRelate::snpgdsVCF2GDS(
#   vcf.fn = "genotypes.vcf.gz",
#   out.fn = "genotypes.gds",
#   method = "biallelic.only"
# )
# 
# gds <- read_geno("genotypes.gds")

## ----plink, eval=FALSE--------------------------------------------------------
# bed <- read_geno("genotypes.bed")

## ----bigmemory, eval=FALSE----------------------------------------------------
# backed <- read_geno_bigmemory(
#   "genotypes.vcf.gz",
#   backingpath = "cache/genotypes"
# )

## ----scalable-options, eval=FALSE---------------------------------------------
# blocks <- run_Big_LD_all_chr(
#   geno_source = "genotypes.gds",
#   CLQmode = "Leiden",
#   max_bp_distance = 500000,
#   subSegmSize = 1500,
#   n_threads = 2
# )

## ----benchmark-schema---------------------------------------------------------
benchmark_schema <- data.frame(
  field = c(
    "dataset_id", "input_sha256", "n_samples", "n_variants",
    "missing_rate", "method", "parameters", "threads", "R_version",
    "HapBlockR_version", "compiler", "hardware", "wall_seconds",
    "cpu_seconds", "peak_resident_mb", "replicate", "correctness_passed"
  ),
  required = TRUE
)
benchmark_schema

## ----session------------------------------------------------------------------
packageVersion("HapBlockR")
sessionInfo()

