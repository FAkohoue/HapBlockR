## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  fig.width = 7,
  fig.height = 4.5,
  message   = FALSE,
  warning   = FALSE
)
library(HapBlockR)
data(ldx_geno,     package = "HapBlockR")
data(ldx_snp_info, package = "HapBlockR")

## ----decision-table, echo=FALSE-----------------------------------------------
dt <- data.frame(
  Criterion = c("Population type", "Computational cost",
                "RAM requirement", "Marker scale",
                "Block accuracy in related pops",
                "External dependencies"),
  `r² (method = 'r2')` = c(
    "Random mating, unrelated, weakly structured",
    "O(np) prep + O(p²) per window via C++",
    "Proportional to one window",
    "Scales to 10 M+ markers",
    "Slightly inflated — blocks too broad",
    "None (always installed)"
  ),
  `rV² (method = 'rV2')` = c(
    "Livestock, inbred lines, family-based cohorts",
    "O(n²p) GRM + O(n³) Cholesky + O(np) whitening",
    "n×n GRM + n×n whitening factor per chromosome",
    "Practical to ~200 k markers per chromosome",
    "Correct for structured populations",
    "AGHmatrix, ASRgenomics (optional Suggests)"
  ),
  check.names = FALSE, stringsAsFactors = FALSE
)
knitr::kable(dt, caption = "r² versus rV²: decision table")

## ----prepare-demo-------------------------------------------------------------
prep_r2 <- prepare_geno(ldx_geno[, 1:30], method = "r2")
str(prep_r2)

## ----whitening-demo-----------------------------------------------------------
set.seed(1)
G_small <- ldx_geno[, 1:30]
Gc      <- scale(G_small, center = TRUE, scale = FALSE)
V_demo  <- tcrossprod(Gc) / 30 + diag(0.05, nrow(Gc))

A_chol <- get_V_inv_sqrt(V_demo, method = "chol")
A_eig  <- get_V_inv_sqrt(V_demo, method = "eigen")

max(abs(A_chol %*% V_demo %*% t(A_chol) - diag(120)))
max(abs(A_eig  %*% V_demo %*% t(A_eig)  - diag(120)))

## ----compare-matrices---------------------------------------------------------
idx_25  <- 1:25
r2_mat  <- compute_r2(ldx_geno[, idx_25])

Gc_25   <- scale(ldx_geno[, idx_25], center = TRUE, scale = FALSE)
V_toy   <- tcrossprod(Gc_25) / 25 + diag(0.1, 120)
A_toy   <- get_V_inv_sqrt(V_toy)
X_whit  <- A_toy %*% Gc_25
rv2_mat <- compute_rV2(X_whit)

cat("Mean r² :", round(mean(r2_mat[upper.tri(r2_mat)]),  4), "\n")
cat("Mean rV²:", round(mean(rv2_mat[upper.tri(rv2_mat)]), 4), "\n")

## ----compare-image, fig.cap="r² (left) vs rV² (right) for the first 25 SNPs on chr1", fig.width=9----
par(mfrow = c(1, 2), mar = c(4, 4, 3, 1))
image(r2_mat,  main = "Standard r²",
      col = hcl.colors(20, "YlOrRd", rev = TRUE),
      xlab = "SNP", ylab = "SNP")
image(rv2_mat, main = "Kinship-adjusted rV²",
      col = hcl.colors(20, "YlOrRd", rev = TRUE),
      xlab = "SNP", ylab = "SNP")
par(mfrow = c(1, 1))

## ----switch, eval=FALSE-------------------------------------------------------
# blocks_r2  <- run_Big_LD_all_chr(be, method = "r2",  CLQcut = 0.70)
# blocks_rv2 <- run_Big_LD_all_chr(be, method = "rV2", CLQcut = 0.70,
#                                   kin_method = "chol")

## ----ld-decay-demo, eval=FALSE------------------------------------------------
# decay <- compute_ld_decay(ldx_geno, ldx_snp_info,
#                            r2_threshold = "both", n_pairs = 2000L, verbose = FALSE)
# cat("Parametric threshold:", round(decay$critical_r2_param, 4), "\n")

