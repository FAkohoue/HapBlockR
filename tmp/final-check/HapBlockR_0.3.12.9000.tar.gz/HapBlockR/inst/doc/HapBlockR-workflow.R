## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)
library(HapBlockR)
set.seed(42)

## ----data---------------------------------------------------------------------
data(ldx_geno)
data(ldx_snp_info)
data(ldx_blocks)
data(ldx_blues)

dim(ldx_geno)
head(ldx_snp_info)
head(ldx_blocks)

## ----identity-----------------------------------------------------------------
stopifnot(
  !is.null(rownames(ldx_geno)),
  !is.null(colnames(ldx_geno)),
  !anyDuplicated(rownames(ldx_geno)),
  !anyDuplicated(colnames(ldx_geno)),
  all(ldx_snp_info$SNP %in% colnames(ldx_geno))
)

## ----external-import, eval=FALSE----------------------------------------------
# imported <- read_geno(
#   "genotypes.vcf.gz",
#   multiallelic = "split",
#   verbose = TRUE
# )

## ----prediction---------------------------------------------------------------
prediction <- run_haplotype_prediction(
  geno_matrix = ldx_geno,
  snp_info = ldx_snp_info,
  blocks = ldx_blocks,
  blues = setNames(ldx_blues$YLD, ldx_blues$id),
  seed = 42,
  min_reliability = 0.30,
  verbose = FALSE
)

names(prediction)
head(prediction$block_importance)
head(prediction$gebv_uncertainty)

## ----validation---------------------------------------------------------------
cv <- cv_haplotype_prediction(
  geno_matrix = ldx_geno,
  snp_info = ldx_snp_info,
  blocks = ldx_blocks,
  blues = setNames(ldx_blues$YLD, ldx_blues$id),
  k = 3,
  seed = 42,
  validation = "random",
  verbose = FALSE
)

cv$pa_pooled
head(cv$gebv_all)
validate(cv)

## ----grouped-validation, eval=FALSE-------------------------------------------
# cv_grouped <- cv_haplotype_prediction(
#   geno_matrix, snp_info, blocks, blues,
#   k = 5,
#   validation = "grouped",
#   groups = family_id,
#   seed = 42
# )

## ----selection----------------------------------------------------------------
top_blocks <- select_top_blocks(
  prediction$block_importance,
  n = min(10L, nrow(prediction$block_importance))
)

value_matrix <- prediction$local_gebv[
  , top_blocks$block_id, drop = FALSE
]

selection <- select_parents_ga(
  value_matrix = value_matrix,
  n_founders = 8,
  seed = 42,
  n_reps = 3,
  verbose = FALSE
)

selection$selected
selection$stability
validate(selection)

## ----contract-----------------------------------------------------------------
names(selection$result_contract)
summary(selection)
as.data.frame(selection)

## ----session------------------------------------------------------------------
packageVersion("HapBlockR")
sessionInfo()

