## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse   = TRUE,
  comment    = "#>",
  fig.width  = 7,
  fig.height = 4.5,
  message    = FALSE,
  warning    = FALSE
)
library(HapBlockR)
data(ldx_geno,     package = "HapBlockR")
data(ldx_snp_info, package = "HapBlockR")
data(ldx_blocks,   package = "HapBlockR")
data(ldx_blues,    package = "HapBlockR")

## ----add-family---------------------------------------------------------------
set.seed(1)
family_id <- sample(rep(paste0("Fam", sprintf("%02d", 1:12)), each = 10))
names(family_id) <- rownames(ldx_geno)
table(family_id)

## ----index--------------------------------------------------------------------
target_data <- data.frame(
  id = ldx_blues$id,
  trait = "YLD",
  value = ldx_blues$YLD,
  precision = 1
)
targets <- prepare_breeding_targets(
  target_data,
  input_type = "BLUE",
  precision_col = "precision"
)
head(targets$targets)

## ----run-prediction-----------------------------------------------------------
pred <- run_haplotype_prediction(
  geno_matrix = ldx_geno,
  snp_info    = ldx_snp_info,
  blocks      = ldx_blocks,
  blues       = targets,
  marker_effect_method   = "gblup",
  complete_decomposition = TRUE,
  verbose     = FALSE
)

pred$n_blocks                                    # includes singleton pseudo-blocks
sum(pred$block_importance$important)              # blocks clearing the 0.9 cutoff
head(pred$block_importance[
  order(-pred$block_importance$var_scaled),
  c("block_id", "CHR", "n_snps", "var_scaled", "important")
])

## ----funnel-plot, fig.alt="Funnel plot of per-block local GEBV against scaled variance, with important blocks highlighted above the 0.9 threshold line"----
plot_block_funnel(
  local_gebv          = pred$local_gebv,
  block_importance    = pred$block_importance,
  highlight_threshold = 0.9,
  max_blocks          = 2000L
)

## ----top-blocks---------------------------------------------------------------
top_blocks <- select_top_blocks(
  block_importance  = pred$block_importance,
  n                 = NULL,
  perc_total        = NULL,
  perc_of_total_var = 0.90,
  var_col           = "var_scaled"
)

nrow(top_blocks)
top_blocks[, c("block_id", "CHR", "n_snps", "var_scaled", "cum_var_share")]

## ----ga-vs-ts-----------------------------------------------------------------
value_matrix <- pred$local_gebv[, top_blocks$block_id, drop = FALSE]

ga_sel <- select_parents_ga(
  value_matrix   = value_matrix,
  n_founders     = 20L,
  strategy       = "no_selfing",
  block_weights  = top_blocks$var_scaled,
  top_candidates = NULL,
  popSize        = 100L,
  maxiter        = 200L,
  run            = 50L,
  pmutation      = 0.1,
  pcrossover     = 0.8,
  penalty_weight = NULL,
  seed           = 1L,
  verbose        = FALSE,
  n_reps         = 2L              # reduced for vignette build speed; the
                                    # package default is 5 — see below
)

ts_sel <- truncation_selection(score = pred$gebv, n_founders = 20L)

length(intersect(ga_sel$selected, ts_sel$selected))   # parents both methods agree on
sort(ga_sel$selected)

## ----ga-stability-------------------------------------------------------------
ga_sel$converged                          # did the winning replicate plateau?
ga_sel$stability$fitness_range            # best fitness, across replicates
sort(ga_sel$stability$selection_freq, decreasing = TRUE)[1:10]

## ----merit-weight-ga----------------------------------------------------------
ga_hybrid <- select_parents_ga_ts(
  value_matrix   = value_matrix,
  n_founders     = 20L,
  strategy       = "no_selfing",
  block_weights  = top_blocks$var_scaled,
  merit_score    = pred$gebv,
  merit_weight   = 0.5,            # advanced raw multiplier
  min_sel_value  = 0.5,
  min_sel_mode   = "percentile",
  seed           = 1L,
  verbose        = FALSE,
  n_reps         = 2L              # reduced for vignette build speed
)

ga_hybrid$mean_merit                       # realised mean merit_score of the chosen set
mean(pred$gebv[ga_sel$selected])           # vs. Section 5.2's coverage-only run

## ----merit-priority-----------------------------------------------------------
cal <- suggest_merit_weight(
  value_matrix   = value_matrix,
  merit_score    = pred$gebv,
  n_founders     = 20L,
  strategy       = "no_selfing",
  block_weights  = top_blocks$var_scaled,
  merit_priority = 50                    # "half as much weight as coverage"
)
cal$merit_span; cal$coverage_span; cal$suggested_merit_weight

ga_dial <- select_parents_ga_ts(
  value_matrix   = value_matrix,
  n_founders     = 20L,
  strategy       = "no_selfing",
  block_weights  = top_blocks$var_scaled,
  merit_score    = pred$gebv,
  merit_priority = 50,              # calibrated internally — no merit_weight guess
  min_sel_value  = 0.5,
  min_sel_mode   = "percentile",
  seed           = 1L,
  verbose        = FALSE,
  n_reps         = 2L
)
ga_dial$merit_weight               # the value merit_priority = 50 resolved to

## ----target-degree------------------------------------------------------------
ga_degree <- select_parents_ga(
  value_matrix   = value_matrix,
  n_founders     = 20L,
  strategy       = "no_selfing",
  block_weights  = top_blocks$var_scaled,
  G              = pred$G,
  target_degree  = 30,              # same convention as select_parents_ocs()
  seed           = 1L,
  verbose        = FALSE,
  n_reps         = 2L
)
ga_degree$relatedness_ceiling      # the ceiling target_degree = 30 resolved to
ga_degree$mean_relationship        # the chosen set's actual realised relationship

## ----family-quota-selection---------------------------------------------------
haps <- extract_haplotypes(ldx_geno, ldx_snp_info, ldx_blocks, min_snps = 3L)

fam_sel <- select_parents_by_family(
  score         = pred$gebv,
  family        = family_id,
  n_families    = 6L,
  n_per_family  = 3L,
  ensure_haplotype_diversity = TRUE,
  value_matrix  = value_matrix,
  haplotypes    = haps,           # auto-derives allele identity per block
  diversity_method = "dominant_block"  # allele-level check needs `haplotypes`;
                                        # the new default, "coverage_gain",
                                        # ignores `haplotypes` — see below
)

fam_sel$family_ranking[, c("family", "topk_mean", "shrinkage_weight", "rank_score", "n_members", "rank", "selected")]
fam_sel$by_family[, c("family", "individual", "score", "dominant_block", "collision")]

## ----pca-plot, fig.alt="PCA scatterplot of all 120 candidates coloured by whether they were GA-selected, truncation-selected, both, or neither"----
plot_parent_selection_pca(
  G           = pred$G,
  ga_selected = ga_sel$selected,
  ts_selected = ts_sel$selected
)

## ----family-balance-----------------------------------------------------------
family_summary <- function(selected_ids, label) {
  tab <- sort(table(family_id[selected_ids]), decreasing = TRUE)
  cat(label, "-- top family:", names(tab)[1], "with",
      round(100 * tab[1] / length(selected_ids)), "% of selected parents\n")
  tab
}

family_summary(ga_sel$selected, "GA selection")
family_summary(ts_sel$selected, "Truncation selection")

## ----ga-vs-ts-sim, eval=FALSE-------------------------------------------------
# # phased$hap1 / phased$hap2: SNPs x individuals, from read_phased_vcf()
# # or run_ldx_pipeline(phase = TRUE)
# phased <- read_phased_vcf("mydata_phased.vcf.gz")
# 
# sim <- ga_vs_ts_simulation(
#   hap1                 = phased$hap1,
#   hap2                 = phased$hap2,
#   snp_info             = phased$snp_info,
#   snp_effects          = pred$snp_effects,
#   ga_selected          = ga_sel$selected,
#   ts_selected          = ts_sel$selected,
#   n_generations        = 10L,
#   pop_size             = 100L,
#   recomb_rate          = 1e-8,
#   selection_intensity  = 0.2,
#   seed                 = 1L,
#   verbose              = FALSE
# )
# 
# plot_ga_vs_ts_simulation(sim, show_max = TRUE)
# 
# # Per-generation mean/max GEBV for each scheme:
# sim$summary[sim$summary$scheme == "GA", ]
# sim$summary[sim$summary$scheme == "TS", ]

## ----ga-vs-ts-sim-schemes, eval=FALSE-----------------------------------------
# sim4 <- ga_vs_ts_simulation(
#   hap1          = phased$hap1,
#   hap2          = phased$hap2,
#   snp_info      = phased$snp_info,
#   snp_effects   = pred$snp_effects,
#   schemes = list(
#     GA  = list(founders = ga_sel$selected, mating_scheme = "truncation"),
#     TS  = list(founders = ts_sel$selected, mating_scheme = "truncation"),
#     OCS = list(founders = ts_sel$selected, mating_scheme = "ocs",
#               n_crosses = 20L),
#     UC  = list(founders = ts_sel$selected, mating_scheme = "uc",
#               selected_proportion = 0.1)
#   ),
#   blocks        = blocks,       # only needed because the "uc" scheme is here
#   n_generations = 10L,
#   seed          = 1L,
#   verbose       = FALSE
# )
# 
# plot_ga_vs_ts_simulation(sim4)

## ----usefulness-criterion-----------------------------------------------------
uc <- usefulness_criterion(
  parent_ids           = ga_sel$selected,
  gebv                 = pred$gebv,
  selected_proportion  = 0.1,
  variance_model        = "block_independent",
  block_importance      = top_blocks,
  local_gebv            = pred$local_gebv,
  segregation_factor    = 0.5,
  verbose               = FALSE
)

nrow(uc)                                        # one row per candidate pair
head(uc[, c("parent1", "parent2", "mid_parent_gebv",
            "predicted_variance", "UC", "rank")], 10L)

## ----uc-top-cross-------------------------------------------------------------
top_cross <- uc[uc$rank == 1L, ]
top_cross[, c("parent1", "parent2", "mid_parent_gebv", "predicted_variance", "UC")]
pred$gebv[c(top_cross$parent1, top_cross$parent2)]      # their individual GEBVs
range(pred$gebv[ga_sel$selected])                        # vs. the full shortlist's range

## ----ocs-check----------------------------------------------------------------
have_ocs_optisel <- requireNamespace("optiSel", quietly = TRUE) &&
  all(c("candes", "opticont", "matings", "noffspring") %in%
        getNamespaceExports("optiSel"))
have_ocs_optisel   # this section's code only runs if TRUE

## ----ocs, eval=have_ocs_optisel-----------------------------------------------
ocs_res <- select_parents_ocs(
  merit          = pred$gebv[ga_sel$selected],
  G              = pred$G,
  family         = family_id[ga_sel$selected],
  engine         = "optisel",       # true OCS via optiSel's own solver;
                                     # see "Which engine should you use?"
                                     # above — use "simplemating" instead
                                     # if you specifically want SimpleMating's
                                     # discrete cross-selection algorithm
  n_crosses      = 15L,
  target_degree  = 30,
  allow_selfing  = FALSE,
  verbose        = FALSE
)

ocs_res$engine_used
ocs_res$ok                                       # constraints satisfied?
head(ocs_res$mating_plan)
head(ocs_res$contributors[order(-ocs_res$contributors$contribution), ])

## ----pareto-sweep-------------------------------------------------------------
pareto_res <- select_parents_pareto(
  value_matrix        = value_matrix,          # from Section 5.2
  n_founders          = 20L,
  strategy            = "no_selfing",
  block_weights       = top_blocks$var_scaled,
  G                   = pred$G,
  coancestry_weights  = c(0, 1, 4),             # narrowed for vignette build
                                                 # speed; package default
                                                 # sweeps 6 grid points
  merit               = pred$gebv,
  popSize             = 100L,
  maxiter             = 200L,
  run                 = 50L,
  n_reps              = 2L,                     # reduced for vignette build
                                                 # speed (default 3)
  seed                = 1L,
  verbose             = FALSE
)

pareto_res$frontier[, c("coancestry_weight", "mean_merit",
                        "mean_relationship", "pareto_optimal")]

## ----exact-check--------------------------------------------------------------
have_lpsolve <- requireNamespace("lpSolve", quietly = TRUE)
have_lpsolve   # this section's code only runs if TRUE

## ----exact-validate, eval=have_lpsolve----------------------------------------
uc_top <- utils::head(uc[!is.na(uc$UC), ], 40L)   # keep the ILP small/fast

naive_top15 <- utils::head(uc_top[order(-uc_top$UC), ], 15L)  # naive: just
                                                                # take the top
                                                                # 15 by UC

exact_res <- validate_crosses_exact(
  data           = uc_top,
  n_cross        = 15L,
  max_cross      = 3L,          # no parent in more than 3 of the 15 crosses
  criterion_col  = "UC",
  heuristic_plan = naive_top15,
  verbose        = FALSE
)

exact_res$exact_objective
exact_res$heuristic_objective
exact_res$gap_pct

## ----core-collection----------------------------------------------------------
core_res <- select_core_collection(
  G             = pred$G,
  n_core        = 15L,
  type          = "relationship",
  strategy      = "maximin",
  merit         = pred$gebv,
  min_sel_value = 0.5,
  min_sel_mode  = "percentile",   # keep only the top 50% by pred$gebv first
  seed          = 1L,
  verbose       = FALSE
)

core_res$mean_distance
core_res$min_distance
sort(core_res$selected)
length(intersect(core_res$selected, ga_sel$selected))   # overlap with Section 5's block-coverage set

## ----final-shortlist----------------------------------------------------------
final_parents <- data.frame(
  Genotype       = ga_sel$selected,
  SelectionIndex = pred$gebv[ga_sel$selected],
  Family         = family_id[ga_sel$selected],
  WholeGenomeGEBV = pred$gebv[ga_sel$selected],
  stringsAsFactors = FALSE
)
final_parents[order(-final_parents$SelectionIndex), ]

