## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE
)
library(HapBlockR)

## ----configure, eval=FALSE----------------------------------------------------
# options(HapBlockR.beagle_jar = "/absolute/path/to/beagle.jar")
# 
# # Alternatively:
# Sys.setenv(HAPBLOCKR_BEAGLE_JAR = "/absolute/path/to/beagle.jar")

## ----run, eval=FALSE----------------------------------------------------------
# phased <- phase_with_beagle(
#   input_vcf = "genotypes.vcf.gz",
#   out_prefix = "results/genotypes_phased",
#   nthreads = 2,
#   seed = 42,
#   ref_panel = "reference.vcf.gz",
#   map_file = "genetic.map",
#   min_genotype_concordance = 0.99,
#   min_imputation_rate = 0.95,
#   return_details = TRUE
# )
# 
# phased$output_vcf
# phased$quality_control
# phased$provenance

## ----phased-fixture-----------------------------------------------------------
vcf <- tempfile(fileext = ".vcf")
writeLines(
  c(
    "##fileformat=VCFv4.2",
    paste(
      "#CHROM", "POS", "ID", "REF", "ALT", "QUAL",
      "FILTER", "INFO", "FORMAT", "P01", "P02",
      sep = "\t"
    ),
    paste("1", "100", "s1", "A", "G", ".", "PASS", ".",
          "GT", "0|1", "1|1", sep = "\t"),
    paste("1", "200", "s2", "C", "T", ".", "PASS", ".",
          "GT", "0|0", "1|0", sep = "\t")
  ),
  vcf
)

parsed <- read_phased_vcf(vcf)
parsed$hap1
parsed$hap2
parsed$dosage
stopifnot(
  identical(parsed$dosage, parsed$hap1 + parsed$hap2),
  identical(parsed$sample_ids, c("P01", "P02"))
)

## ----pipeline, eval=FALSE-----------------------------------------------------
# result <- run_ldx_pipeline(
#   geno_source = "genotypes.vcf.gz",
#   out_dir = "results",
#   out_blocks = "results/blocks.csv",
#   out_diversity = "results/diversity.csv",
#   out_hap_matrix = "results/haplotypes.csv",
#   phase = TRUE,
#   beagle_jar = "/absolute/path/to/beagle.jar",
#   beagle_threads = 2,
#   beagle_seed = 42,
#   use_bigmemory = TRUE
# )

## ----session------------------------------------------------------------------
packageVersion("HapBlockR")
sessionInfo()

