# DesiredGainR

DesiredGainR provides auditable multi-trait selection indices for plant
breeding. It implements: (i) an optimised Desired-Gain Selection Index (DGSI)
following Joukhadar et al. (2024), and (ii) a Quadratic Genomic Selection
Index (QGSI) following Cerón-Rojas et al. (2026).

The two methods answer different questions. DGSI searches for a linear index
whose selected-set response approaches breeder-specified trait gains. QGSI
combines linear, squared and cross-product contributions from genomic
estimated breeding values (GEBVs). Neither method replaces the upstream
genetic model that produces the trait values and covariance matrices.

## Installation

```r
remotes::install_github("FAkohoue/DesiredGainR")
```

```r
library(DesiredGainR)
```

## Desired-Gain Selection Index

`run_dgsi()` requires:

- one candidate row per genotype and one column per trait;
- a named desired-gain vector `dg`;
- a genetic covariance matrix `G`;
- a phenotypic or index-variable covariance matrix `P`, or reference values
  from which an explicitly labelled working covariance can be estimated;
- trait directions;
- the requested selection size; and
- a random seed and replicated-search specification.

Candidate observations are not relabelled as a genetic covariance matrix. `G`
must be supplied from an appropriate upstream genetic analysis. If `P` is
omitted, the returned covariance provenance describes the estimated matrix as
an empirical working covariance.

```r
set.seed(41)
traits <- c("yield", "protein", "disease")
candidates <- data.frame(
  GenoID = paste0("G", seq_len(80)),
  yield = rnorm(80),
  protein = rnorm(80),
  disease = rnorm(80)
)
G <- cov(candidates[traits])
dimnames(G) <- list(traits, traits)

dgsi <- run_dgsi(
  init_data = candidates["GenoID"],
  cand_data = candidates,
  trait_cols = traits,
  dg = c(yield = 0.6, protein = 0.3, disease = 0.4),
  G = G,
  lower_is_better = "disease",
  n_select = 12,
  n_iter = 500,
  n_rep = 10,
  seed = 20260725
)
```

The function runs all optimisation replicates and automatically returns the
replicate with the smallest desired-response objective. The breeder does not
inspect every run and choose one manually.

```r
dgsi$best_replicate
dgsi$replicate_diagnostics
dgsi$coefficient_stability
dgsi$rank_correlation
dgsi$selected_set_agreement
head(dgsi$ranked_geno)
```

The diagnostics report: (i) the objective and iteration of the best solution
within each replicate, (ii) whether the final search window reached a plateau,
(iii) coefficient variability, (iv) rank correlation, and (v) Jaccard
agreement among selected sets.

### Eligibility thresholds

In `select_mode = "eligible_top_n"`, `trait_min` defines the eligible
candidate pool after all traits have been oriented so that larger is
favourable. The optimised index then ranks eligible candidates and selects the
best `n_select`. Thresholds do not replace index ranking.

```r
eligible_dgsi <- run_dgsi(
  init_data = candidates["GenoID"],
  cand_data = candidates,
  trait_cols = traits,
  dg = c(yield = 0.6, protein = 0.3, disease = 0.4),
  G = G,
  lower_is_better = "disease",
  select_mode = "eligible_top_n",
  trait_min = c(yield = -0.5, protein = -0.5, disease = -0.5),
  n_select = 12,
  n_iter = 500,
  n_rep = 10,
  seed = 20260725
)
```

Missing values are rejected by default. `missing_policy = "complete_cases"`
or `"mean_impute"` must be requested explicitly, and the chosen policy is
recorded in the result. Independent `validation_data` are evaluated only
after optimisation and do not determine the winning replicate.

## Quadratic Genomic Selection Index

`run_qgsi()` calculates

`QGSI_i = w' gamma_i + gamma_i' W gamma_i`,

where `gamma_i` is the trait GEBV vector for candidate `i`, `w` is the linear
weight vector and `W` is a symmetric matrix of squared and cross-product
weights. Both `w` and `W` refer to the transformed trait space used in the
call.

DesiredGainR does not construct `W` automatically from desired gains. An
automatically positive diagonal can reward a large unfavourable deviation
because squaring removes its sign. Therefore, the breeder must supply a
scientifically and economically justified matrix whose signs and scale match
the breeding objective.

```r
W <- matrix(
  c(
     0.10,  0.02, -0.01,
     0.02,  0.05,  0.00,
    -0.01,  0.00,  0.08
  ),
  nrow = 3,
  dimnames = list(traits, traits)
)

qgsi <- run_qgsi(
  init_data = candidates["GenoID"],
  gebv_data = candidates,
  trait_cols = traits,
  linear_weights = c(yield = 1, protein = 0.5, disease = 0.7),
  W = W,
  lower_is_better = "disease"
)

head(qgsi$ranked_geno)
head(qgsi$linear_contributions)
head(qgsi$quadratic_contributions)
```

QGSI contributions are candidate-specific. They describe why a particular
candidate received its score; they are not one global additive marker-effect
vector. Linear indices can propagate to marker or haplotype effects through a
trait-weighted sum. The nonlinear QGSI term must remain candidate-specific.

## Result contract

Both engines return:

- the method and original call;
- the transformed trait space and direction;
- covariance or weight provenance;
- ranked candidate scores;
- component and stability diagnostics; and
- optional detailed replicate or contribution tables.

Legacy function names remain as wrappers during the package transition:
`run_desired_gain_index_Joukhadar2024()` calls `run_dgsi()`, and
`run_qgsi_desired_gain()` calls `run_qgsi()`. New analyses should use the
short canonical names.

## References

- Joukhadar R, Li Y, Thistlethwaite R, Forrest KL, Tibbits JF, Trethowan R,
  Hayden MJ (2024). Optimising desired gain indices to maximise selection
  response. *Frontiers in Plant Science* 15:1337388.
  <https://doi.org/10.3389/fpls.2024.1337388>
- Cerón-Rojas JJ, Montesinos-López OA, Montesinos-López A, et al. (2026).
  Nonlinear genomic selection index accelerates multi-trait crop improvement.
  *Nature Communications* 17:1991.
  <https://doi.org/10.1038/s41467-026-69890-3>
