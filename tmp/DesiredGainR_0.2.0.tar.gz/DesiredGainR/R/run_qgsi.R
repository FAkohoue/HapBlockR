#' Score candidates with a quadratic genomic selection index
#'
#' `run_qgsi()` implements the candidate-level score
#' \deqn{I_i = w^\mathsf{T}\hat{\gamma}_i +
#' \hat{\gamma}_i^\mathsf{T}W\hat{\gamma}_i.}
#' The function does not infer `W` from the desired-gain vector. The linear
#' weights and the symmetric squared/cross-product weight matrix must be
#' supplied explicitly in the same transformed trait space as the genomic
#' estimated breeding values.
#'
#' @param init_data Candidate identifiers and metadata.
#' @param gebv_data Candidate identifiers and trait genomic estimated breeding
#'   values (GEBVs).
#' @param trait_cols Trait GEBV columns.
#' @param linear_weights Named linear-weight vector `w`.
#' @param W Symmetric squared and cross-product weight matrix.
#' @param id_col Candidate identifier.
#' @param lower_is_better Traits whose original direction is unfavourable when
#'   larger. They are multiplied by -1 before scoring.
#' @param center_traits,scale_traits Whether to transform the GEBVs before
#'   scoring. Supplied weights must refer to the resulting trait space.
#' @param missing_policy Explicit missing-value policy.
#' @param return_contributions Whether to return candidate-specific linear and
#'   quadratic contribution tables.
#' @param debug Whether to print progress messages.
#'
#' @return An object of class `quadratic_genomic_index` with candidate rankings,
#'   component scores, transformations, and optionally contribution tables.
#' @export
run_qgsi <- function(
    init_data,
    gebv_data,
    trait_cols,
    linear_weights,
    W,
    id_col = "GenoID",
    lower_is_better = NULL,
    center_traits = FALSE,
    scale_traits = FALSE,
    missing_policy = c("error", "complete_cases", "mean_impute"),
    return_contributions = TRUE,
    debug = FALSE
) {
  missing_policy <- match.arg(missing_policy)
  if (missing(W)) {
    stop(
      "W is required. DesiredGainR does not fabricate a quadratic-weight matrix from desired gains.",
      call. = FALSE
    )
  }
  prepared <- .dgr_prepare_values(
    init_data = init_data,
    cand_data = gebv_data,
    ref_data = gebv_data,
    validation_data = NULL,
    trait_cols = trait_cols,
    id_col = id_col,
    lower_is_better = lower_is_better,
    scale_traits = scale_traits,
    centre_traits = center_traits,
    missing_policy = missing_policy
  )
  X <- prepared$candidate_matrix

  weights <- .dgr_named_vector(
    linear_weights, trait_cols, "linear_weights"
  )
  if (!is.matrix(W) || max(abs(W - t(W))) >
      sqrt(.Machine$double.eps)) {
    stop("W must be a symmetric matrix.", call. = FALSE)
  }
  W <- .dgr_covariance(W, trait_cols, "W")

  linear_by_trait <- sweep(X, 2L, weights, "*")
  linear_score <- rowSums(linear_by_trait)
  quadratic_score <- rowSums((X %*% W) * X)
  total_score <- linear_score + quadratic_score

  ranked <- data.table::copy(prepared$init_data)
  ranked[, LinearPart := linear_score]
  ranked[, QuadraticPart := quadratic_score]
  ranked[, QGSI := total_score]
  ranked[, Rank := data.table::frank(-QGSI, ties.method = "average")]
  data.table::setorder(ranked, -QGSI)

  linear_contributions <- NULL
  quadratic_contributions <- NULL
  if (isTRUE(return_contributions)) {
    linear_contributions <- data.table::as.data.table(linear_by_trait)
    data.table::setnames(
      linear_contributions,
      paste0("Linear_", trait_cols)
    )
    linear_contributions[, (id_col) := prepared$init_data[[id_col]]]
    data.table::setcolorder(linear_contributions, id_col)

    pairs <- which(upper.tri(W, diag = TRUE), arr.ind = TRUE)
    pair_values <- vapply(seq_len(nrow(pairs)), function(k) {
      i <- pairs[k, 1L]
      j <- pairs[k, 2L]
      multiplier <- if (i == j) 1 else 2
      multiplier * W[i, j] * X[, i] * X[, j]
    }, numeric(nrow(X)))
    if (is.null(dim(pair_values))) {
      pair_values <- matrix(pair_values, ncol = 1L)
    }
    pair_names <- vapply(seq_len(nrow(pairs)), function(k) {
      paste0(
        "Quadratic_", trait_cols[pairs[k, 1L]], "_x_",
        trait_cols[pairs[k, 2L]]
      )
    }, character(1))
    colnames(pair_values) <- pair_names
    quadratic_contributions <- data.table::as.data.table(pair_values)
    quadratic_contributions[, (id_col) := prepared$init_data[[id_col]]]
    data.table::setcolorder(quadratic_contributions, id_col)
  }

  result <- list(
    method = "QGSI",
    call = match.call(),
    linear_weights = weights,
    W = W,
    transformation = prepared$transformation,
    missing_data = prepared$missing_data,
    ranked_geno = ranked,
    component_summary = data.table::data.table(
      Component = c("LinearPart", "QuadraticPart", "QGSI"),
      Mean = c(mean(linear_score), mean(quadratic_score), mean(total_score)),
      SD = c(stats::sd(linear_score), stats::sd(quadratic_score),
             stats::sd(total_score)),
      Min = c(min(linear_score), min(quadratic_score), min(total_score)),
      Max = c(max(linear_score), max(quadratic_score), max(total_score))
    ),
    linear_contributions = linear_contributions,
    quadratic_contributions = quadratic_contributions,
    contribution_scope = paste(
      "QGSI contributions are candidate-specific. They are not a single",
      "global additive marker-effect vector."
    )
  )
  class(result) <- c("quadratic_genomic_index", "list")
  .dgqgsi_dbg(debug, "Scored %d candidates with QGSI.", nrow(X))
  result
}
