#' DesiredGainR: Auditable Multi-trait Selection Indices
#'
#' Package providing tools for:
#' \itemize{
#'   \item desired-gain selection index optimization,
#'   \item quadratic genomic selection index computation from trait genomic
#'     estimated breeding values and explicit linear and quadratic weights,
#'   \item comparison of DG and QGSI outputs,
#'   \item a high-level wrapper for full pipeline execution.
#' }
#'
#' @importFrom utils globalVariables
#' @keywords internal
"_PACKAGE"
