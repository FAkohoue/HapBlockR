library(testthat)
library(DesiredGainR)
test_check("DesiredGainR")
